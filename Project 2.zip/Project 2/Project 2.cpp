#include <iostream>
#include <vector>
#include <string>
#include <algorithm>
using namespace std;

// using structure to hold the student data
struct Student {
    string name;
    int id;
};

// Comparison the functions
bool compareByID(const Student& a, const Student& b) {
    return a.id < b.id;
}

bool compareByName(const Student& a, const Student& b) {
    return a.name < b.name;
}

// using binary search for ID
int binarySearchByID(const vector<Student>& students, int targetID) {
    int low = 0; 
    int high = static_cast<int>(students.size()) - 1;
    while (low <= high) {
        int mid = (low + high) / 2;
        if (students[mid].id == targetID)
            return mid;
        else if (students[mid].id < targetID)
            low = mid + 1;
        else
            high = mid - 1;
    }
    return -1; // Not found
}

// Display the student records
void displayStudents(const vector<Student>& students) {
    cout << "\nThe Student Records : \n";
    cout << "----------------------------\n";
    for (const auto& student : students) {
        cout << "ID: " << student.id << ", Name : " << student.name << "\n";
    }
    cout << "----------------------------\n";
}

int main() {
    vector<Student> students;
    int n;

    // Input the students
    cout << "Enter the number of students : ";
    cin >> n;
    for (int i = 0; i < n; ++i) {
        Student s;
        cout << "Enter the name of student " << i + 1 << ": ";
        cin >> ws;
        getline(cin, s.name);
        cout << "Enter the ID of student " << i + 1 << ": ";
        cin >> s.id;
        students.push_back(s);
    }

    // Menu options and display
    int choice;

    do {
        cout << "\nMenu:\n";
        cout << "1. Display all students\n";
        cout << "2. Sort by ID\n";
        cout << "3. Sort by Name\n";
        cout << "4. Search by ID\n";
        cout << "5. Exit\n";
        cout << "Enter your choice : (1-5) ";
        cin >> choice;

        switch (choice) {
        case 1:
            displayStudents(students);
            break;

        case 2:
            sort(students.begin(), students.end(), compareByID);
            cout << "\nSorted by ID.\n";
            displayStudents(students);
            break;

        case 3:
            sort(students.begin(), students.end(), compareByName);
            cout << "\nSorted by Name.\n";
            displayStudents(students);
            break;

        case 4: {
            int targetID;
            cout << "Enter ID to search : ";
            cin >> targetID;

            // make sure the data is sorted by ID before binary search
            sort(students.begin(), students.end(), compareByID);
            int index = binarySearchByID(students, targetID);

            if (index != -1) {
                cout << "Student found : " << students[index].name << " (ID : " << students[index].id << ")\n";
            }
            else {
                cout << "Student with ID " << targetID << " not found.\n";
            }
            break;
        }

        case 5:
            cout << "Exiting the program...\n";
            break;

        default:
            cout << "Invalid choice.Try again.\n";
        }

    } while (choice != 5);

    return 0;
}